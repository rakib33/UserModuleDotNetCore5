﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;

namespace UserManagementCore.Models
{
    public class ApplicationUser : IdentityUser
    {
        [StringLength(20)]
        public string Tag { get; set; }
        public virtual ICollection<ApplicationUserClaim> Claims { get; set; }
        public virtual ICollection<ApplicationUserLogin> Logins { get; set; }
        public virtual ICollection<ApplicationUserToken> Tokens { get; set; }
        public virtual ICollection<ApplicationUserRole> UserRoles { get; set; }
    }

    public class ApplicationRole : IdentityRole
    {
        [StringLength(250)]
        public string Description { get; set; }
        public virtual ICollection<ApplicationUserRole> UserRoles { get; set; }
        public virtual ICollection<ApplicationRoleClaim> RoleClaims { get; set; }
        public virtual ICollection<ApplicationRoleDetails> RoleDetails { get; set; }
    }

    public class ApplicationRoleDetails 
    {

        [Key]
        public virtual int Id { get; set; }

        [StringLength(50)]
        public virtual string ActionName { get; set; }
        [StringLength(50)]
        public virtual string ControllerName { get; set; }
        [StringLength(100)]
        public virtual string Url { get; set; }

        public virtual bool IsActive { get; set; }
        public virtual DateTime? CreatedDate { get; set; }
        public virtual string CreatedBy { get; set; }
        public virtual DateTime? UpdateDate { get; set; }
        public virtual string UpdateBy { get; set; }
        public virtual ApplicationRole Role { get; set; }
    }
    public class ApplicationUserRole : IdentityUserRole<string>
    {
        public virtual ApplicationUser User { get; set; }
        public virtual ApplicationRole Role { get; set; }
    }

    public class ApplicationUserClaim : IdentityUserClaim<string>
    {
        public virtual ApplicationUser User { get; set; }
    }

    public class ApplicationUserLogin : IdentityUserLogin<string>
    {
        public virtual ApplicationUser User { get; set; }
    }

    public class ApplicationRoleClaim : IdentityRoleClaim<string>
    {
        public virtual ApplicationRole Role { get; set; }
    }

    public class ApplicationUserToken : IdentityUserToken<string>
    {
        public virtual ApplicationUser User { get; set; }
    }
    public class ApplicationDbContext : IdentityDbContext<
        ApplicationUser, ApplicationRole, string,
        ApplicationUserClaim, ApplicationUserRole, ApplicationUserLogin,
        ApplicationRoleClaim, ApplicationUserToken>
    {

        public DbSet<ApplicationRoleDetails> RoleDetails { get; set; }
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
            
        }
        //protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        //{
        //    optionsBuilder.UseSqlServer(@"Server=.\SQLEXPRESS;Database=SchoolDB;Trusted_Connection=True;");
        //}

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
         
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<ApplicationUser>(b =>
            {
                b.ToTable("MyUsers");
                // Each User can have many UserClaims
                b.HasMany(e => e.Claims)
                    .WithOne(e => e.User)
                    .HasForeignKey(uc => uc.UserId)
                    .IsRequired();

                // Each User can have many UserLogins
                b.HasMany(e => e.Logins)
                    .WithOne(e => e.User)
                    .HasForeignKey(ul => ul.UserId)
                    .IsRequired();

                // Each User can have many UserTokens
                b.HasMany(e => e.Tokens)
                    .WithOne(e => e.User)
                    .HasForeignKey(ut => ut.UserId)
                    .IsRequired();

                // Each User can have many entries in the UserRole join table
                b.HasMany(e => e.UserRoles)
                    .WithOne(e => e.User)
                    .HasForeignKey(ur => ur.UserId)
                    .IsRequired();
            });
            modelBuilder.Entity<ApplicationUserClaim>(b =>
            {
                b.ToTable("MyUserClaims");
            });
            //IdentityUserLogin<string>
            modelBuilder.Entity<ApplicationUserLogin>(b =>
            {
                b.HasKey(l => new { l.LoginProvider, l.ProviderKey });      //, l.UserId         
                b.ToTable("MyUserLogins");
            });
            //IdentityUserToken<string>
            modelBuilder.Entity<ApplicationUserToken>(b =>
            {
                b.HasKey(l=> new { l.UserId,l.LoginProvider,l.Name});
                b.ToTable("MyUserTokens");
            });
            modelBuilder.Entity<ApplicationRole>(b =>
            {
                b.ToTable("MyRoles");
                // Each Role can have many entries in the UserRole join table
                b.HasMany(e => e.UserRoles)
                    .WithOne(e => e.Role)
                    .HasForeignKey(ur => ur.RoleId)
                    .IsRequired();

                // Each Role can have many associated RoleClaims
                b.HasMany(e => e.RoleClaims)
                    .WithOne(e => e.Role)
                    .HasForeignKey(rc => rc.RoleId)
                    .IsRequired();
            });
            //IdentityRoleClaim<string>
            modelBuilder.Entity<ApplicationRoleClaim>(b =>
            {              
                b.ToTable("MyRoleClaims");
            });
            //IdentityUserRole<string>
            modelBuilder.Entity<ApplicationUserRole>(b =>
            {
                b.HasKey(l => new { l.UserId, l.RoleId });
                b.ToTable("MyUserRoles");
            });
            modelBuilder.Entity<ApplicationRoleDetails>(b =>
            {
                b.ToTable("MyRoleDetails");
            });
        }
    }
}
